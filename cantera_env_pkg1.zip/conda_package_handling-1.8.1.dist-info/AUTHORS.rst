All of the people who have made at least one contribution to conda-package-handling.
Authors are sorted by number of commits.

* Michael Sarahan
* Ray Donnelly
* leej3
* Jonathan J. Helmus
* Jannis Leidel
* Nehal J Wani
* Alan Du
* Cheng H. Lee
* conda-bot
* Matthew R. Becker
* Daniel Bast
* Daniel Holth
* Christopher Barber
* ossdev07
* Eli Uriegas
* Chris Burr
* vz-x
* Tobias "Tobi" Koch
